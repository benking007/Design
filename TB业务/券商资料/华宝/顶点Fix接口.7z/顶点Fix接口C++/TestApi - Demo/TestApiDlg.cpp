// TestApiDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TestApi.h"
#include "TestApiDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About
 
class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//afx_msg void IDC_BUTTON_SUBSB();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//ON_BN_CLICKED(IDOK, IDC_BUTTON_SUBSB)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestApiDlg dialog

CTestApiDlg::CTestApiDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestApiDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestApiDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
    m_Conn = NULL;
}

void CTestApiDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestApiDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTestApiDlg, CDialog)
	//{{AFX_MSG_MAP(CTestApiDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_CLOSE, OnClose)
	ON_BN_CLICKED(IDC_NEW, OnNew)
	ON_BN_CLICKED(IDC_RUN, OnRun)
	ON_BN_CLICKED(IDC_QUERY, OnQuery)
	ON_BN_CLICKED(IDC_INIT, OnInit)
	ON_BN_CLICKED(IDC_UNINIT, OnUninit)
    //ON_BN_CLICKED(IDC_BUTTON_L2, OnButtonL2)
	ON_BN_CLICKED(IDC_BUTTON_SUBCJ, OnButtonSubcj)
	ON_BN_CLICKED(IDC_BUTTON_ASYNC, OnButtonAsync)
	ON_BN_CLICKED(IDC_BUTTON_SUBSB, OnButtonSubsb)
	ON_BN_CLICKED(IDC_BUTTON_SUBCD, OnButtonSubcd)
	ON_BN_CLICKED(IDC_BUTTON_WT, OnButtonWt)
	ON_BN_CLICKED(IDC_BUTTON_CD, OnButton2Cd)
	ON_BN_CLICKED(IDC_BUTTON_HQ, OnButtonHq)
	ON_BN_CLICKED(IDC_BUTTON_PLWT, OnButtonPlwt)
	ON_BN_CLICKED(IDC_BUTTON_PLCD, OnButtonPlcd)
	
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestApiDlg message handlers

BOOL CTestApiDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
 

//	/IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}
 
	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon    
    GetDlgItem( IDC_EDIT_ADDR )->SetWindowText( "192.168.1.95@9061/tcp" );
	GetDlgItem( IDC_EDIT_KHH)->SetWindowText( "02102003" );
	GetDlgItem( IDC_EDIT_MM )->SetWindowText( "123123" );
	GetDlgItem( IDC_EDIT_GDH )->SetWindowText( "A685506671" );
	GetDlgItem( IDC_EDIT_JYS )->SetWindowText( "SH" );
	GetDlgItem( IDC_EDIT_ZQDM )->SetWindowText( "600123" );
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTestApiDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTestApiDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTestApiDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}
 
 
void CTestApiDlg::OnNew() 
{

    if( m_Conn )
    {
        Fix_Close( m_Conn );
        m_Conn = NULL;
    }

    CString sAddr;
	CString sKhh;
	CString sMm;
	CString sWTh;
	CString sGDh;
	CString sJYs;
	CString sZqdm;

    UpdateData();
    GetDlgItem( IDC_EDIT_ADDR )->GetWindowText( sAddr );
	GetDlgItem( IDC_EDIT_KHH )->GetWindowText( sKhh );
	GetDlgItem( IDC_EDIT_MM )->GetWindowText( sMm );
	GetDlgItem( IDC_EDIT_WTH )->GetWindowText( sWTh );
	GetDlgItem( IDC_EDIT_GDH)->GetWindowText( sGDh );
	GetDlgItem( IDC_EDIT_JYS)->GetWindowText( sJYs );
	GetDlgItem( IDC_EDIT_ZQDM)->GetWindowText( sZqdm );

    m_Conn=Fix_SetAppInfo("FanHan","2.0");

    Fix_SetDefaultInfo( "FanHan", "32", "9999", "1001" );
    m_Conn = Fix_Connect( sAddr, "FanHan", "123456", 30 ); 
    if( m_Conn == NULL )
    {
        CString sNote;
 
        sNote.Format( "Connect Svr fail!\n%s", sAddr );
        AfxMessageBox( sNote );
        return;
    }
	AfxMessageBox( "���ӳɹ�" );
    return; 
}
 
void CTestApiDlg::OnRun() 
{ 


	if( m_Conn == NULL )
        return;
    char out[512];

    HANDLE_SESSION sess;
	CString sKhh;
	CString sMm;
	char szPwd[64];
	memset(szPwd, 0, sizeof(szPwd));

 	GetDlgItem( IDC_EDIT_KHH )->GetWindowText( sKhh );
 	GetDlgItem( IDC_EDIT_MM )->GetWindowText( sMm );

	strcpy (szPwd, sMm);
	Fix_Encode(szPwd);

    
    sess = Fix_AllocateSession( m_Conn );
	Fix_SetNode( sess, "192.168.1.81,D0-67-E5-2C-5A-23,61H4D08HB");
	Fix_SetWTFS(sess,"4");
    Fix_CreateReq( sess, 610301 );
    Fix_SetString( sess, 605, sKhh );
    Fix_SetString( sess, 598, szPwd);
    if( Fix_Run(sess) )
    {        
        Fix_GetLong( sess, 507 );
		Fix_GetCode(sess);
        Fix_GetErrMsg( sess, out, sizeof(out) );  
	   
    }
    else
    {
        Fix_GetCode(sess);
		Fix_GetErrMsg( sess, out, sizeof(out) );

	
		
    }

    AfxMessageBox( out );
    Fix_ReleaseSession( sess );
	//Fix_WriteLog(TRUE);



/*	sess = Fix_AllocateSession( m_Conn );
	 	Fix_SetNode( sess, "192.168.1.81,D0-67-E5-2C-5A-23");
	 	Fix_CreateReq( sess, 620021 );
	     Fix_SetLong( sess, 739, 1 );
	     Fix_SetString( sess, 605, "36000029" );
	     Fix_SetString( sess, 598, sMm);
	     Fix_SetLong( sess, 781, 2 );
	 	Fix_SetLong(sess,FID_WTH,7);
	 	Fix_SetString(sess,FID_ZJZH,"36000029");
	     if( Fix_Run(sess) )
	     {        
	         Fix_GetLong( sess, 507 );
	 		Fix_GetErrMsg( sess, out, sizeof(out) );        
	     }
	     else
	     {
	         
	 		Fix_GetErrMsg( sess, out, sizeof(out) );
	 		
	 		
	 		
	     }
	     AfxMessageBox( out );
	     Fix_ReleaseSession( sess );*///��������
 
 
    return; 
}

void CTestApiDlg::OnQuery() 
{
    if( m_Conn == NULL )
        return;
    int i;
    char out[512];
    HANDLE_SESSION sess;
	CString sKhh;
	CString sMm;
	char szPwd[64];
	
	memset(szPwd, 0, sizeof(szPwd));

 	GetDlgItem( IDC_EDIT_KHH )->GetWindowText( sKhh );
	GetDlgItem( IDC_EDIT_MM )->GetWindowText( sMm );
	
	strcpy (szPwd, sMm);
	Fix_Encode(szPwd);

	sess = Fix_AllocateSession( m_Conn );
	Fix_SetNode( sess, "liyi-192.168.1.81,MAC:D0-67-E5-2C-5A-23");
    Fix_CreateReq( sess, 630005 );
    Fix_SetString( sess, 605, sKhh );
	Fix_SetString( sess, 598, szPwd );
	Fix_SetLong(sess,FID_BROWINDEX ,7);
	Fix_SetLong(sess,FID_ROWCOUNT ,200);
	Fix_SetLong(sess,FID_WTH ,4);
    Fix_SetLong( sess, 1100, (long)1 );
    Fix_SetLong( sess, 1102, (long)1 );
    Fix_SetLong( sess, 1103, (long)1 );

    if( Fix_Run( sess ) )
    {
        CString sNote;
        for( i = 0; i < Fix_GetCount(sess); i++ )
        {
            Fix_GetItem( sess, 507, out, sizeof(out), i );
            sNote += out;
            sNote += "\n";
        }
		sNote.Format("����, %d",i);

        AfxMessageBox( sNote );
		Fix_GetErrMsg( sess, out, sizeof(out) );
        AfxMessageBox( out );


    }
    else
    {
        Fix_GetErrMsg( sess, out, sizeof(out) );
        AfxMessageBox( out );
    }
	

	
    Fix_ReleaseSession( sess );	
}
 
void CTestApiDlg::OnClose() 
{
    if( m_Conn == NULL )
        return;
    Fix_Close( m_Conn );
    m_Conn = NULL;    
}

void CTestApiDlg::OnInit() 
{
    //ֻ�ܵ���һ��
	Fix_Initialize();
	Fix_WriteLog(TRUE);
    GetDlgItem( IDC_INIT )->EnableWindow( FALSE );
    GetDlgItem( IDC_NEW )->EnableWindow( TRUE );
}

void CTestApiDlg::OnUninit() 
{
    //ֻ�ܵ���һ��
	Fix_Uninitialize();
    GetDlgItem( IDC_INIT )->EnableWindow( FALSE );
	GetDlgItem( IDC_UNINIT )->EnableWindow( FALSE );
    GetDlgItem( IDC_NEW )->EnableWindow( FALSE );
    GetDlgItem( IDC_CLOSE )->EnableWindow( FALSE );
    GetDlgItem( IDC_RUN )->EnableWindow( FALSE );
    GetDlgItem( IDC_QUERY )->EnableWindow( FALSE );
    //GetDlgItem( IDC_FILE )->EnableWindow( FALSE );
//    GetDlgItem( IDC_REGSVC )->EnableWindow( FALSE );
	GetDlgItem( IDC_UNINIT )->EnableWindow( FALSE );
    GetDlgItem( IDC_BUTTON_CD )->EnableWindow( FALSE );
    GetDlgItem( IDC_BUTTON_SUBSB )->EnableWindow( FALSE );
    GetDlgItem( IDC_BUTTON_SUBCD )->EnableWindow( FALSE );
    GetDlgItem( IDC_BUTTON_SUBCJ )->EnableWindow( FALSE );
    GetDlgItem( IDC_BUTTON_WT )->EnableWindow( FALSE );
    GetDlgItem( IDC_BUTTON_PLWT )->EnableWindow( FALSE );
	GetDlgItem(IDC_BUTTON_PLCD)->EnableWindow(FALSE);
    GetDlgItem( IDC_BUTTON_ASYNC )->EnableWindow( FALSE );
	
}

#include "DlgL2.h"
#include "zlib.h"
#include<fstream>
#pragma comment(lib, "zlib.lib")

void CTestApiDlg::OnButtonPlwt() 
{

	if( m_Conn == NULL )
        return;
   // char out[512];
	
    HANDLE_SESSION sess;
	CString sKhh;
	CString sMm;
	char out[16*1024]="";
	char msg[16*1024]="";
	char szPwd[64];
	CString sTemp;

	int nLength=16*1024;
	int nLength2=16*1024;

	memset(szPwd, 0, sizeof(szPwd));
	
	GetDlgItem( IDC_EDIT_KHH )->GetWindowText( sKhh );
	GetDlgItem( IDC_EDIT_MM )->GetWindowText( sMm );
	
	strcpy (szPwd, sMm);
	Fix_Encode(szPwd);
	sess = Fix_AllocateSession( m_Conn );
	Fix_SetNode( sess, "192.168.1.81-D0,67-E5-2C-5A-23");
	Fix_CreateReq( sess, 620002 );
    Fix_SetLong( sess, 739, 1 );
	Fix_SetString( sess, 605, sKhh );
	Fix_SetString( sess, 598, szPwd);
	Fix_SetLong(sess,FID_COUNT,2);
	Fix_SetLong(sess,FID_LOGICAL,1);
	Fix_SetString(sess,FID_FJXX,"SZ000002200008.240000001000000SZ000002100008.240000001000000");

	
	if( Fix_Run(sess) )
	{        
		Fix_GetItemBuf(sess, out, nLength2,-1);
		uncompress((unsigned char *)msg, (unsigned long *)&nLength, (const unsigned char *)out, nLength2);
	
		sTemp.Format("Message:\n%s\n,",msg);
		AfxMessageBox( sTemp );

		Fix_GetLong( sess, 507 );
		Fix_GetErrMsg( sess, out, sizeof(out) );        
	}
	else
	{
		
		Fix_GetErrMsg( sess, out, sizeof(out) );
		
		
		
	}
	Fix_ReleaseSession( sess );//����ί��
	AfxMessageBox( out );
	   

}

//extern bool OnQuoteFresh(HANDLE_CONN conn, HANDLE_SESSION sess, long nSubs, void *pData);
extern bool OnWtFresh(HANDLE_CONN conn, HANDLE_SESSION sess, long nSubs, void *pData);
extern bool OnSbFresh(HANDLE_CONN conn, HANDLE_SESSION sess, long nSubs, void *pData);
extern bool OnCdFresh(HANDLE_CONN conn, HANDLE_SESSION sess, long nSubs, void *pData);
void CTestApiDlg::OnButtonSubcj() 
{
	char szPwd [64];

	CString sKhh;
	CString sMm;



	memset(szPwd, 0, sizeof(szPwd));
	
	
	GetDlgItem( IDC_EDIT_KHH )->GetWindowText( sKhh );
	GetDlgItem( IDC_EDIT_MM )->GetWindowText( sMm );
	
	strcpy (szPwd, sMm);
	Fix_Encode(szPwd);


	long lSubscibe = Fix_MDBSubscibeByCustomer(m_Conn, 100064, OnWtFresh, "", sKhh, szPwd);
	if (lSubscibe < 1)
	{
		AfxMessageBox("����ʧ��");

		return ;
	}
	else
	{
		AfxMessageBox("���ĳɹ�");
		return ;
	}

	
	Fix_UnSubscibeByHandle(lSubscibe);
}


void CTestApiDlg::OnButtonSubsb() 
{
	char szPwd [64];

	CString sKhh;
	CString sMm;

	memset(szPwd, 0, sizeof(szPwd));
	
	GetDlgItem( IDC_EDIT_KHH )->GetWindowText( sKhh );
	GetDlgItem( IDC_EDIT_MM )->GetWindowText( sMm );
	
	strcpy (szPwd, sMm);
	Fix_Encode(szPwd);
	

	long lSubscibe = Fix_MDBSubscibeByCustomer(m_Conn, 100065, OnSbFresh, "", sKhh, szPwd);
	if (lSubscibe < 1)
	{
		AfxMessageBox("����ʧ��");
		return ;
	}
	else
	{
		AfxMessageBox("���ĳɹ�");
		return ;
	}
	
	Fix_UnSubscibeByHandle(lSubscibe);
}


void CTestApiDlg::OnButtonSubcd() 
{
	char szPwd [64];

	CString sKhh;
	CString sMm;
	
	memset(szPwd, 0, sizeof(szPwd));
	
	GetDlgItem( IDC_EDIT_KHH )->GetWindowText( sKhh );
	GetDlgItem( IDC_EDIT_MM )->GetWindowText( sMm );
	
	strcpy (szPwd, sMm);
	Fix_Encode(szPwd);

	long lSubscibe = Fix_MDBSubscibeByCustomer(m_Conn, 100066, OnCdFresh, "", sKhh, szPwd);
	if (lSubscibe < 1)
	{
		AfxMessageBox("����ʧ��");
		return ;
	}
	else
	{
		AfxMessageBox("���ĳɹ�");
		return ;
	}
	
	Fix_UnSubscibeByHandle(lSubscibe);
}

bool OnAsyncReply(HANDLE_CONN hConn, HANDLE_SESSION hSess, int nRecv)
{
	char out[512];
	CString sTemp;
	
	if (nRecv < 0)
	{
		Fix_GetErrMsg(hSess, out, 511);
		sTemp.Format("�첽����Ӧ��ʧ��:%li/%s", Fix_GetCode(hSess), out);
		AfxMessageBox(sTemp);
		return true;
	}
	
    char tmp[100]="itemdata=null";
	long nRetCode = Fix_GetCode(hSess);
    char *p = (char *)Fix_GetSessData( hSess );
    if( !p )
        p = tmp;
	
	Fix_GetErrMsg(hSess, out, 511);
	if (nRetCode < 0)
	{
		sTemp.Format("ʧ��:%li/%s %s", nRetCode, out, p);
		AfxMessageBox(sTemp);
		return true;
	}
	
	sTemp.Format("ί�к�:%li %s", Fix_GetLong(hSess, FID_WTH), p);
	AfxMessageBox(sTemp);
	return true;
}

void CTestApiDlg::OnButtonAsync() 
{
	CString sKhh;
	CString sMm;
	CString sGDh;
	CString sJYs;
	CString sZqdm;
	char szPwd[64];
	
	
	memset(szPwd, 0, sizeof(szPwd));
	
	GetDlgItem( IDC_EDIT_KHH )->GetWindowText( sKhh );
	GetDlgItem( IDC_EDIT_MM )->GetWindowText( sMm );
	GetDlgItem( IDC_EDIT_GDH )->GetWindowText( sGDh );
	GetDlgItem( IDC_EDIT_JYS )->GetWindowText( sJYs );
	GetDlgItem( IDC_EDIT_ZQDM )->GetWindowText( sZqdm );
	
	strcpy (szPwd, sMm);
	Fix_Encode(szPwd);
	

    if (NULL == m_Conn)
	{
		return;
	}
	
    char out[512];
    
    char *pData=new char[100];
    strcpy(pData, "sessdata:testdemo" );
	
    HANDLE_SESSION sess;
	
	sess = Fix_AllocateSession( m_Conn );
	Fix_RegReplyCallFunc(sess, OnAsyncReply);
    Fix_SetSessData( sess, pData );
//     Fix_CreateReq( sess, 610101 );
//     Fix_SetLong( sess, 1100, (long)1 );


	Fix_SetNode( sess, "liyi-IP:192.168.1.81,MAC:D0-67-E5-2C-5A-23,61H4D08HB");
	Fix_CreateReq( sess, 620001 );
    Fix_SetString( sess, FID_KHH, sKhh );
    Fix_SetString( sess, FID_GDH, sGDh );
    Fix_SetString( sess, FID_JYS, sJYs );
    Fix_SetString( sess, FID_ZQDM, sZqdm );
	Fix_SetItem( sess, FID_WTJG, "12.62");
	Fix_SetLong( sess, FID_WTSL, 1000);
	Fix_SetLong( sess, FID_WTLB, 1);
	Fix_SetLong( sess, FID_DDLX, 0 );
	Fix_SetString( sess, FID_JYMM, szPwd );

    if (!Fix_AsyncRun( sess ))
    {
		CString sTemp;
		
		Fix_GetErrMsg(sess, out, 511);
		sTemp.Format("�첽��������ʧ��:%li/%s", Fix_GetCode(sess), out);
		AfxMessageBox(sTemp);
    }
	
    Fix_ReleaseSession( sess );
}



void CTestApiDlg::OnButtonWt() 
{
	if( m_Conn == NULL )
        return;
    char out[512];
	
    HANDLE_SESSION sess;
	CString sKhh;
	CString sMm;
	CString sGDh;
	CString sJYs;
	CString sZqdm;
	char szPwd[64];

	
	memset(szPwd, 0, sizeof(szPwd));

	GetDlgItem( IDC_EDIT_KHH )->GetWindowText( sKhh );
 	GetDlgItem( IDC_EDIT_MM )->GetWindowText( sMm );
	GetDlgItem( IDC_EDIT_GDH )->GetWindowText( sGDh );
	GetDlgItem( IDC_EDIT_JYS )->GetWindowText( sJYs );
	GetDlgItem( IDC_EDIT_ZQDM )->GetWindowText( sZqdm );

	strcpy (szPwd, sMm);
	Fix_Encode(szPwd);

	
	

    
    sess = Fix_AllocateSession( m_Conn );
//	Fix_SetNode( sess, "liyi-IP:192.168.1.81,MAC:D0-67-E5-2C-5A-23,61H4D08HB");
	Fix_SetNode( sess, "liyi-IP:192.168.1.81,mac:D0-67-E5-2C-5A-23;dsn:61H4D08HB;cpuid:1231231;");
//	Fix_SetWTFS(sess,"4");
	Fix_CreateReq( sess, 620001 );
    Fix_SetString( sess, FID_KHH, sKhh );
    Fix_SetString( sess, FID_GDH, sGDh );
    Fix_SetString( sess, FID_JYS, sJYs );
    Fix_SetString( sess, FID_ZQDM, sZqdm );
	Fix_SetItem( sess, FID_WTJG, "12.62");
	Fix_SetLong( sess, FID_WTSL, 1000);
	Fix_SetLong( sess, FID_WTLB, 1);
	Fix_SetLong( sess, FID_DDLX, 0 );
	Fix_SetString( sess, FID_JYMM, szPwd );

    if( Fix_Run(sess) )
    {        
        Fix_GetLong( sess, 507 );
		Fix_GetErrMsg( sess, out, sizeof(out) );        
    }
    else
    {
        
		Fix_GetErrMsg( sess, out, sizeof(out) );
		
		
		
    }
    AfxMessageBox( out );
    Fix_ReleaseSession( sess );//ί��
	//Fix_WriteLog(TRUE);
		


	
}

void CTestApiDlg::OnButton2Cd() 
{
	if( m_Conn == NULL )
        return;
    char out[512];
	
    HANDLE_SESSION sess;
	CString sKhh;
	CString sMm;
    CString sWTh;

	char szPwd[64];
	
	memset(szPwd, 0, sizeof(szPwd));

	GetDlgItem( IDC_EDIT_WTH )->GetWindowText( sWTh );
	GetDlgItem( IDC_EDIT_KHH )->GetWindowText( sKhh );
 	GetDlgItem( IDC_EDIT_MM )->GetWindowText( sMm );
	
	strcpy (szPwd, sMm);
	Fix_Encode(szPwd);
	
	
	
    
    sess = Fix_AllocateSession( m_Conn );
	Fix_SetNode( sess, "liyi-IP:192.168.1.81,MAC:D0-67-E5-2C-5A-23,61H4D08HB");
	Fix_CreateReq( sess, 620021 );
    Fix_SetString( sess, FID_KHH, sKhh );
    Fix_SetString( sess, FID_WTH, sWTh );
	Fix_SetString( sess, FID_JYMM, szPwd );
    if( Fix_Run(sess) )
    {        
        Fix_GetLong( sess, 507 );
		Fix_GetErrMsg( sess, out, sizeof(out) );        
    }
    else
    {
        
		Fix_GetErrMsg( sess, out, sizeof(out) );
		
		
		
    }
    AfxMessageBox( out );
    Fix_ReleaseSession( sess );//����
	

	
}
void CTestApiDlg::OnButtonPlcd() 
{
	if( m_Conn == NULL )
        return;
    char out[512];
	
    HANDLE_SESSION sess;
	CString sKhh;
	CString sMm;
	CString sEn_WTH;
	CString sWtpch;
	char szPwd[64];
	memset(szPwd, 0, sizeof(szPwd));
	
	GetDlgItem( IDC_EDIT_EN_WTH )->GetWindowText( sEn_WTH );
	GetDlgItem( IDC_EDIT_WTPCH )->GetWindowText( sWtpch );
	GetDlgItem( IDC_EDIT_KHH )->GetWindowText( sKhh );
	GetDlgItem( IDC_EDIT_MM )->GetWindowText( sMm );
	
	strcpy (szPwd, sMm);
	Fix_Encode(szPwd);
	sess = Fix_AllocateSession( m_Conn );
	Fix_SetNode( sess, "192.168.1.81,D0-67-E5-2C-5A-23");
	Fix_CreateReq( sess, 620022 );
    Fix_SetLong( sess, 739, 1 );
	Fix_SetString( sess, 605, sKhh );
	Fix_SetString( sess, 598, szPwd);
	Fix_SetString(sess,FID_EN_WTH,sEn_WTH);
	Fix_SetString(sess,FID_WTPCH,sWtpch);

	if( Fix_Run(sess) )
	{        
		Fix_GetLong( sess, 507 );
		Fix_GetErrMsg( sess, out, sizeof(out) );        
	}
	else
	{
		
		Fix_GetErrMsg( sess, out, sizeof(out) );
		
		
		
	}
	AfxMessageBox( out );
	Fix_ReleaseSession( sess );//��������ί��
	
}


extern bool OnRtnMarketPrice(HANDLE_CONN conn, HANDLE_SESSION sess, long nSubs, void *pData);
void CTestApiDlg::OnButtonHq() 
{
    long lSubscibe = Fix_SubscibeQuoteByZQDM(m_Conn, OnRtnMarketPrice,"","","600110,600123,000562");
	//long lSubscibe1 =Fix_SubscibeIndexByCode(m_Conn, OnQuoteFresh,NULL,"","300000,399999");
	if (lSubscibe > 0)
	{
		AfxMessageBox("���ĳɹ�");
		return ;
	}

	if (lSubscibe < 0)
		{
			AfxMessageBox("����ʧ��");
			return ;
		}
	AfxMessageBox("���ĳɹ�");
	
	Fix_UnSubscibeByHandle(lSubscibe);
	
}
