// DlgL2.cpp : implementation file
//

#include "stdafx.h"
#include "testapi.h"
#include "DlgL2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgL2 dialog


CDlgL2::CDlgL2(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgL2::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgL2)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	m_lSubscibe = 0;
}


void CDlgL2::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgL2)
	DDX_Control(pDX, IDC_LIST_L2, m_listL2);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgL2, CDialog)
	//{{AFX_MSG_MAP(CDlgL2)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()



bool OnRtnMarketPrice(HANDLE_CONN conn, HANDLE_SESSION sess, long nSubs, void *pData)
{
	long sub=nSubs;
    char jys[12];
	char szTemp[1024];
	int nOutlen = 1023;
	float fzxj,fzsp;
	Fix_GetItemBuf(sess,szTemp,nOutlen,0);
	Fix_GetItem(sess,599,jys,12,0);
	struct tagQL1_MMP *pstQL1_MMP = (struct tagQL1_MMP *)szTemp;	
	fzxj=pstQL1_MMP->m_fZXJ; /* ���¼�(������ָ��) */
	fzsp=pstQL1_MMP->m_fZSP;/* ������,*/

	CString sNote;

	sNote.Format("֤ȯ����,���¼�,������,��һ����,����۸�,:%s,%f;%f;%u;%.3lf",pstQL1_MMP->m_szZQDM,pstQL1_MMP->m_fZXJ,pstQL1_MMP->m_fZSP,pstQL1_MMP->m_nMRSL[0], (double)pstQL1_MMP->m_fMRJG[0]);



	if( strnicmp( jys, "SH", 2 ) ==  0 )

    {
        AfxMessageBox(sNote );
    }

    return true;
}


bool OnQuoteFresh(HANDLE_CONN conn, HANDLE_SESSION sess, long nSubs, void *pData)
{

	CDlgL2 * pDlgL2 = (CDlgL2 *)pData;
	CListBox * pListBox = &pDlgL2->m_listL2;
	CString sTemp;
	char szTemp[1024];
	
	pListBox->ResetContent();
	sTemp.Format("������:%s", Fix_GetItem(sess, FID_JYS, szTemp, 511));
	AfxMessageBox( sTemp);
	pListBox->AddString(sTemp);
	sTemp.Format("֤ȯ����:%s", Fix_GetItem(sess, FID_ZQDM, szTemp, 511));
	pListBox->AddString(sTemp);
	
	TQL2_MMP *pstMMP;
	int nLen = 0;
	
	Fix_GetItemBuf(sess, szTemp, nLen, -1);
	pstMMP = (TQL2_MMP *)szTemp;
	
	sTemp.Format("���¼�:%.3lf", (double)pstMMP->m_fZXJ);
	pListBox->AddString(sTemp);
	AfxMessageBox( sTemp);
	sTemp.Format("��һ:%u;%.3lf", pstMMP->m_nMRSL[0], (double)pstMMP->m_fMRJG[0]);
	pListBox->AddString(sTemp);
	sTemp.Format("��һ:%u;%.3lf", pstMMP->m_nMCSL[0], (double)pstMMP->m_fMCJG[0]);
	pListBox->AddString(sTemp);
	sTemp.Format("�ɽ�����:%l64d", pstMMP->m_lCJSL);
	pListBox->AddString(sTemp);
	sTemp.Format("�ɽ����:%.3lf", (double)pstMMP->m_dCJJE);
	pListBox->AddString(sTemp);
	AfxMessageBox( sTemp);

	return true;
}
bool OnWtFresh(HANDLE_CONN conn, HANDLE_SESSION sess, long nSubs, void *pData)
{
	
	CDlgL2 * pDlgL2 = (CDlgL2 *)pData;
	CListBox * pListBox = &pDlgL2->m_listL2;
	CString sTemp;
	char szTemp[1024];
	int nLen = 0;
	
	Fix_GetItemBuf(sess, szTemp, nLen, -1);
	pListBox->ResetContent();
	sTemp.Format("������:%s", Fix_GetItem(sess, FID_JYS, szTemp, 511));
	AfxMessageBox( sTemp);
	pListBox->AddString(sTemp);
	sTemp.Format("�ɶ���:%s", Fix_GetItem(sess, FID_GDH, szTemp, 511));
	pListBox->AddString(sTemp);
	AfxMessageBox( sTemp);
	sTemp.Format("����:%s", Fix_GetItem(sess, FID_BZ, szTemp, 511));
	pListBox->AddString(sTemp);
	AfxMessageBox( sTemp);
	sTemp.Format("֤ȯ����:%s", Fix_GetItem(sess, FID_ZQDM, szTemp, 511));
    pListBox->AddString(sTemp);
	AfxMessageBox( sTemp);
// 	sTemp.Format("������־:%s", Fix_GetItem(sess, FID_CXBZ, szTemp, 511));
// 	pListBox->AddString(sTemp);
// 	sTemp.Format("�ɽ����:%s", Fix_GetItem(sess, FID_CJBH, szTemp, 511));
// 	pListBox->AddString(sTemp);
// 	AfxMessageBox( sTemp);
// 	sTemp.Format("ί�к�:%s", Fix_GetItem(sess, FID_WTH, szTemp, 511));
// 	pListBox->AddString(sTemp);
// 	AfxMessageBox( sTemp);
// 	sTemp.Format("ί�����:%s", Fix_GetItem(sess, FID_WTLB, szTemp, 511));
// 	pListBox->AddString(sTemp);
// 	AfxMessageBox( sTemp);
// 	sTemp.Format("�����ʽ�:%s", Fix_GetItem(sess, FID_QSZJ, szTemp, 511));
// 	pListBox->AddString(sTemp);
// 	AfxMessageBox( sTemp);
// 	sTemp.Format("�ܳɽ�����:%s", Fix_GetItem(sess, FID_ZCJSL, szTemp, 511));
// 	pListBox->AddString(sTemp);
// 	AfxMessageBox( sTemp);
// 	sTemp.Format("�ܳɽ����:%s", Fix_GetItem(sess, FID_ZCJJE, szTemp, 511));
// 	pListBox->AddString(sTemp);
// 	AfxMessageBox( sTemp);
// 	sTemp.Format("�ɽ�����:%s", Fix_GetItem(sess, FID_CJSL, szTemp, 511));
// 	pListBox->AddString(sTemp);
// 	AfxMessageBox( sTemp);
// 	sTemp.Format("�ɽ��۸�:%s", Fix_GetItem(sess, FID_CJJG, szTemp, 511));
// 	pListBox->AddString(sTemp);
// 	AfxMessageBox( sTemp);
// 	sTemp.Format("�ɽ����:%s", Fix_GetItem(sess, FID_CJJE, szTemp, 511));
// 	pListBox->AddString(sTemp);
//     AfxMessageBox( sTemp);
	sTemp.Format("ί�����κ�:%s", Fix_GetItem(sess, FID_WTPCH, szTemp, 511));
	pListBox->AddString(sTemp);
	AfxMessageBox( sTemp);

	return true;
}
bool OnSbFresh(HANDLE_CONN conn, HANDLE_SESSION sess, long nSubs, void *pData)
{
	
	CDlgL2 * pDlgL2 = (CDlgL2 *)pData;
	CListBox * pListBox = &pDlgL2->m_listL2;
	CString sTemp;
	char szTemp[1024];
	int nLen = 0;

	Fix_GetItemBuf(sess, szTemp, nLen, -1);
	pListBox->ResetContent();
	sTemp.Format("������:%s", Fix_GetItem(sess, FID_JYS, szTemp, 511));
	AfxMessageBox( sTemp);
	pListBox->AddString(sTemp);
	sTemp.Format("֤ȯ����:%s", Fix_GetItem(sess, FID_ZQDM, szTemp, 511));
	pListBox->AddString(sTemp);
	AfxMessageBox( sTemp);
	sTemp.Format("ί�����κ�:%s", Fix_GetItem(sess, FID_WTPCH, szTemp, 511));
	pListBox->AddString(sTemp);
	AfxMessageBox( sTemp);
	return true;
}
bool OnCdFresh(HANDLE_CONN conn, HANDLE_SESSION sess, long nSubs, void *pData)
{
	
	CDlgL2 * pDlgL2 = (CDlgL2 *)pData;
	CListBox * pListBox = &pDlgL2->m_listL2;
	CString sTemp;
	char szTemp[1024];
	int nLen = 0;
	
	pListBox->ResetContent();
	sTemp.Format("������:%s", Fix_GetItem(sess, FID_JYS, szTemp, 511));
	AfxMessageBox( sTemp);
	pListBox->AddString(sTemp);
	sTemp.Format("֤ȯ����:%s", Fix_GetItem(sess, FID_ZQDM, szTemp, 511));
	pListBox->AddString(sTemp);
	AfxMessageBox( sTemp);
	sTemp.Format("ί�����κ�:%s", Fix_GetItem(sess, FID_WTPCH, szTemp, 511));
	pListBox->AddString(sTemp);
	AfxMessageBox( sTemp);
	return true;
}




/////////////////////////////////////////////////////////////////////////////
// CDlgL2 message handlers

BOOL CDlgL2::OnInitDialog() 
{
	CDialog::OnInitDialog();
// 	
// 	m_lSubscibe = Fix_SubscibeL2QuoteByZQDM(m_Conn, OnQuoteFresh, this, "", "601166");
// 	if (m_lSubscibe < 1)
// 	{
// 		AfxMessageBox("����ʧ��");
// 		EndDialog(0);
// 		return FALSE;
// 	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgL2::OnClose() 
{
	if (m_lSubscibe > 0)
	{
		Fix_UnSubscibeByHandle(m_lSubscibe);
		m_lSubscibe = 0;
	}
	
	CDialog::OnClose();
}
