//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TestApi.rc
//
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TESTAPI_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_L2                   129
#define IDC_RUN                         1000
#define IDC_QUERY                       1002
#define IDC_NEW                         1003
#define IDC_CLOSE                       1005
#define IDC_INIT                        1007
#define IDC_UNINIT                      1008
#define IDC_EDIT_ADDR                   1009
#define IDC_ADDR                        1010
#define IDC_BUTTON_HQ                   1012
#define IDC_LIST_L2                     1013
#define IDC_BUTTON_SUBCJ                1014
#define IDC_BUTTON_ASYNC                1015
#define IDC_EDIT_KHH                    1016
#define IDC_EDIT_MM                     1017
#define IDC_EDIT_JYS                    1018
#define IDC_KHH                         1019
#define IDC_MM                          1020
#define IDM_ABOUTBOX                    1022
#define IDC_BUTTON_SUBSB                1024
#define IDC_BUTTON_SUBCD                1025
#define IDC_BUTTON_WT                   1026
#define IDC_BUTTON_CD                   1027
#define IDC_WTH                         1029
#define IDC_EDIT_WTH                    1030
#define IDC_GDH                         1031
#define IDC_EDIT_ZQDM                   1032
#define IDC_EDIT_GDH                    1033
#define IDC_BUTTON_PLWT                 1034
#define IDC_JYS                         1036
#define IDC_ZQDM                        1037
#define IDC_BUTTON_PLCD                 1038
#define IDC_EDIT_EN_WTH                 1039
#define IDC_EDIT_WTPCH                  1041
#define IDC_EN_WTH                      1042
#define IDC_WTPCH                       1043

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1044
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
