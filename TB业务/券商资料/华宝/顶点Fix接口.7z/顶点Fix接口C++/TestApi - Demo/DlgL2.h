#if !defined(AFX_DLGL2_H__5B77C9E3_2F1F_4144_BCC3_605B43D49CF1__INCLUDED_)
#define AFX_DLGL2_H__5B77C9E3_2F1F_4144_BCC3_605B43D49CF1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgL2.h : header file
//
#include "FixApi_mdb.h"
//#include "Quote.h"

/////////////////////////////////////////////////////////////////////////////
// CDlgL2 dialog

class CDlgL2 : public CDialog
{
// Construction
public:
	long m_lSubscibe;
	HANDLE_CONN m_Conn;
	CDlgL2(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgL2)
	enum { IDD = IDD_DIALOG_L2 };
	CListBox	m_listL2;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgL2)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgL2)
	virtual BOOL OnInitDialog();
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGL2_H__5B77C9E3_2F1F_4144_BCC3_605B43D49CF1__INCLUDED_)
