// TestApiDlg.h : header file
//

#if !defined(AFX_TESTAPIDLG_H__2EACD458_7CE3_4BFE_A4A7_301B25A187CF__INCLUDED_)
#define AFX_TESTAPIDLG_H__2EACD458_7CE3_4BFE_A4A7_301B25A187CF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CTestApiDlg dialog
#include "FixApi_mdb.h"
//#include "MDBTrade.h"

class CTestApiDlg : public CDialog
{
// Construction
public:
	CTestApiDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTestApiDlg)
	enum { IDD = IDD_TESTAPI_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestApiDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL
    HANDLE_CONN m_Conn;
// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CTestApiDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	afx_msg void OnNew();
	afx_msg void OnRun();
	afx_msg void OnQuery();
	afx_msg void OnInit();
	afx_msg void OnUninit();
	afx_msg void OnButtonPlwt();
	afx_msg void OnButtonSubcj();
	afx_msg void OnButtonAsync();
	afx_msg void OnButtonSubsb();
	afx_msg void OnButtonSubcd();
	afx_msg void OnButtonWt();
	afx_msg void OnButton2Cd();
	afx_msg void OnButtonPlcd();
	afx_msg void OnButtonHq();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTAPIDLG_H__2EACD458_7CE3_4BFE_A4A7_301B25A187CF__INCLUDED_)
