// TestApi.h : main header file for the TESTAPI application
//

#if !defined(AFX_TESTAPI_H__44B604CF_E863_4CAC_A37C_C0E6302A62CD__INCLUDED_)
#define AFX_TESTAPI_H__44B604CF_E863_4CAC_A37C_C0E6302A62CD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CTestApiApp:
// See TestApi.cpp for the implementation of this class
//

class CTestApiApp : public CWinApp
{
public:
	CTestApiApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestApiApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CTestApiApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTAPI_H__44B604CF_E863_4CAC_A37C_C0E6302A62CD__INCLUDED_)
