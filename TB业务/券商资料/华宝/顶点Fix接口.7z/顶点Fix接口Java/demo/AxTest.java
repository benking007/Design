﻿package com.apex.fix.test;

import com.apex.fix.JFixComm;
import com.apex.fix.JFixSess;

public class AxTest {
	public static void main(String args[]) {
		JFixComm fixComm = null;
		boolean login;
		fixComm = new JFixComm();

		// 开始连接
		fixComm.setAppInfo("chicourser", "1.0.0.1");

		// 是否校验服务器证书 false:不校验，true:校验，默认是 true
		fixComm.setVerify(true);

		// 可选项目,可以多次增加信任证书(作为可配置，允许为空字符串)
		// fixComm.addTrust("d:/aboss2/cert/apex_ca.cer");
		fixComm.addTrust("");

		// 设置客户端证书、客户端证书的密码(可配置参数，允许全部为空字符串)
		fixComm.setCert("e:/cnhbstock_api_chicourser.pfx", "12345678");

		// 启用SSL协议
		// fixComm.enableSSL();
		// 启用TSL协议
		// fixComm.enableTLS();

		// 开始连接 地址链接串 ip@port/cp 通信用户(可以为空) 通信密码(可以为空)
		login = fixComm.login("10.105.0.200@9062/tcp", "", "");
		if (login == false) {
			System.out.println("与中间件建立连接失败:" + fixComm.getErrMsg());
			return;
		} else {
			System.out.println("成功与中间件建立连接!");
		}

		// 连接完成

		// 发出业务请求
		int i = 0;
		JFixSess sess = fixComm.alloceteSess();
		sess.createHead(630003);
		sess.setItem(605, "010000006611");
		sess.setItem(598, "123321");
		sess.setItem(781, "2");			
		while (sess.more()) {
			i++;
                        System.out.println( "read:" + i + " "+  sess.getItem(507) );
                        System.out.println( "read:" + i + " "+  sess.getItem(508) );
                        System.out.println( "read:" + i + " "+  sess.getItem(571) );
                        System.out.println( "read:" + i + " "+  sess.getItem(574) );
			System.out.println( "read:" + i + " "+  sess.getItem(1532) );
			System.out.println( "read:" + i + " "+  sess.getItem(599) );
                        System.out.println( "read:" + i + " "+  sess.getItem(691) );
                        System.out.println( "read:" + i + " "+  sess.getItem(716) );
                        System.out.println( "read:" + i + " "+  sess.getItem(727) );
                        System.out.println( "read:" + i + " "+  sess.getItem(1007) );
			System.out.println( "read:" + i + " "+  sess.getItem(1257) );
		}
		System.out.println( "总记录数:" + sess.getCount() );

		// 发出订阅请求
			 sess = fixComm.alloceteSess();
		 sess.createHead(100064);		 
		 if( sess.subscibeByKHH(  "010000006611", "123321", new AxPubData()) <= 0 )
			 System.out.println( "错误消息:" + sess.getErrMsg() );
	
	     try {
			Thread.sleep(100000000);
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	
		fixComm.close();
	}
}
