package com.apex.fix.test;

import com.apex.fix.AxPublish;
import com.apex.fix.JFixSess;

public class AxPubData implements  AxPublish{
	public boolean OnRecvData( JFixSess sess )
	{
		System.out.println( "�յ���������:" + sess.getItem( 1201 ) );		
		return true;
	}
}
